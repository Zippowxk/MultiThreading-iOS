//
//  ViewController.m
//  01 Thread
//
//  Created by wang xinkai on 15/9/13.
//  Copyright (c) 2015年 wxk. All rights reserved.
//

#import "ViewController.h"
#import "CNThread.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    

//   栈空间 主线程 1024K 其他 512K
    UIImage *a_image = [UIImage imageNamed:@"xxx"];
    
//    a_image 储存在栈内存中  8bit
//    UIImage对象储存在堆中 300K


    
//    在当前线程中调用
//    [self detachMethod];
//    [self performSelector:<#(SEL)#> withObject:<#(id)#>];
    
    
// 开启一个新的线程的4中方法
    
//   1 Detach方式 ，隐式创建
//    detachMethod就是线程的入口方法
//    每个NSThread都有main方法，这里相当于在main方法中 self调用了detachMethod
//    [NSThread detachNewThreadSelector:@selector(detachMethod) toTarget:self withObject:nil];
    
    
    
//  2 NSObject的perform方法 ，隐式创建
//    使用方式跟上一个方式类似
//    [self performSelectorInBackground:@selector(detachMethod) withObject:nil];
    

//  3  显式创建
    NSThread *thread_0 = [[NSThread alloc] initWithTarget:self selector:@selector(detachMethod) object:nil];
    //    给线程name 赋值
    thread_0.name = @"thread_0_name";
    
    //在线程创建之前 设置栈空间 才有效
    thread_0.stackSize = 100;
    
    //线程全局数据 readOnly
    [thread_0.threadDictionary setObject:@"value1" forKey:@"key1"];
    //错，这是set方法，readOnly 不能用
    //    thread_0.threadDictionary = [[NSMutableDictionary alloc] init];

    //线程优先级
    //范围 0-1 最高是1。 iOS 8 更新中被qualityOfService 替代
    thread_0.threadPriority = 1.0;
    //最高的userInteraction
    thread_0.qualityOfService = NSQualityOfServiceUserInteractive; //不能在线程 start后修改。
    
    //开启线程 (真正创建出一个线程)
    //    [thread_0 start];
    
    
//    4 子类NSThread ，重写main方法
    CNThread *thread_1 = [[CNThread alloc] init];
    [thread_1 start];
    
    
    
}

-(void)detachMethod{

    //    是否是主线程
    NSLog(@"%d",[NSThread isMainThread]);
    
    
    //    获取当前线程，打印name
    NSLog(@"%@",[[NSThread currentThread] name]);

    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
