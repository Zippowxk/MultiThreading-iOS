//
//  ViewController.m
//  05 Atomic
//
//  Created by wang xinkai on 15/9/13.
//  Copyright (c) 2015年 wxk. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    
}

@property (atomic,assign) int ticket,sold;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _ticket = 100;

    
    NSThread *thread0 = [[NSThread alloc] initWithTarget:self selector:@selector(saleTicket) object:nil];
    thread0.name = @"thread_0";
    [thread0 start];
    
    NSThread *thread1 = [[NSThread alloc] initWithTarget:self selector:@selector(saleTicket) object:nil];
    thread1.name = @"thread_1";
    [thread1 start];
    
    NSThread *thread2 = [[NSThread alloc] initWithTarget:self selector:@selector(saleTicket) object:nil];
    thread2.name = @"thread_2";
    [thread2 start];

    
    
}

-(void)saleTicket{
    
    
    int current = _ticket;
    int sold = _sold;
    if (current <= 0) {
        
        NSLog(@"%d %d",_ticket,_sold);
        
        return;
    }
    
    usleep(20000);
    
    current--;
    [self setSold:sold+1];
    [self setTicket:current];
    
    [self saleTicket];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
