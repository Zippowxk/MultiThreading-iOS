//
//  ViewController.m
//  03 TicketThread
//
//  Created by wang xinkai on 15/9/13.
//  Copyright (c) 2015年 wxk. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    //票数
    int _ticket;
    //已卖
    int _sold;
    
//    同步锁
    NSLock *_lock;
    
}



@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    _ticket = 100;
//    [self saleTicket];
    
    
//    创建锁
    _lock = [[NSLock alloc] init];
    
//    创建三个线程 同时卖票

    
    NSThread *thread0 = [[NSThread alloc] initWithTarget:self selector:@selector(saleTicket) object:nil];
    thread0.name = @"thread_0";
    [thread0 start];
    
    NSThread *thread1 = [[NSThread alloc] initWithTarget:self selector:@selector(saleTicket) object:nil];
    thread1.name = @"thread_1";
    [thread1 start];
    
    NSThread *thread2 = [[NSThread alloc] initWithTarget:self selector:@selector(saleTicket) object:nil];
    thread2.name = @"thread_2";
    [thread2 start];
}


-(void)saleXx{
    
    
    
    
    
    
}


-(void)saleTicket{
    
//    加锁的简写方式
    @synchronized(self){

    }
    
//    加锁
//    [_lock lock];
    int current = _ticket;
    
    if (current == 0) {

        NSLog(@"sold %d",_sold);
        NSLog(@"ticket: %d",_ticket);
        //解锁
//        [_lock unlock];
        return;
    }
    //买票延时
    usleep(20000);
    _ticket = current -1;
    _sold++;
    //解锁
//    [_lock unlock];
    NSLog(@"-----sale %@  %d",[[NSThread currentThread] name],_ticket);
        
    [self saleTicket];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
