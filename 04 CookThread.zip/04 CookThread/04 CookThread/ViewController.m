//
//  ViewController.m
//  04 CookThread
//
//  Created by wang xinkai on 15/9/13.
//  Copyright (c) 2015年 wxk. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSCondition *_lock;

}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    _lock = [[NSCondition alloc] init];
    
    [self performSelectorInBackground:@selector(cook) withObject:nil];
    
    [self performSelector:@selector(buyStuff) withObject:nil afterDelay:4];
    
    
}


-(void)cook{
    
    
    [[NSThread currentThread] setName:@"cook_thread"];

    
    NSLog(@"begin Cook");
    NSLog(@"need stuff");
//    开始等待 信号传入
    
    [_lock lock];
    [_lock wait];
    
    NSLog(@"go on");
}


-(void)buyStuff{

    NSLog(@"buy .....");

//    发送信号
    [_lock signal];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
