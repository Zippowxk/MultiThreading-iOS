//
//  CNThread.m
//  02 ThreadRoutine
//
//  Created by wang xinkai on 15/9/13.
//  Copyright (c) 2015年 wxk. All rights reserved.
//

#import "CNThread.h"

@implementation CNThread



-(void)main
{
    @autoreleasepool {
        NSLog(@"starting thread.......");
        NSTimer *timer = [NSTimer timerWithTimeInterval:1
                                                 target:self selector:@selector(doTimerTask) userInfo:nil repeats:YES];
        [[NSRunLoop currentRunLoop] addTimer:timer
                                     forMode:NSDefaultRunLoopMode];
        while (!self.isCancelled) {
            [self doOtherTask];
            
//           如果在doTimerTask中，没有停止RunLoop的操作的话，RunLoop 一直在运行，下面这行代码 永远不会有返回值
            BOOL ret = [[NSRunLoop currentRunLoop]
                        runMode:NSDefaultRunLoopMode beforeDate:[NSDate distantFuture]];
        
            NSLog(@"after runloop counting.........: %d", ret);
        }
        
        
        NSLog(@"finishing thread.........");
    }
}


- (void)doTimerTask
{
    NSLog(@"do timer task");
    
//    添加RunLoop停止代码，使NSRunLoop 的runMode:(NSString *)mode beforeDate:(NSDate *)limitDate方法返回
//    这行代码写在 timer的触发事件中
    CFRunLoopStop(CFRunLoopGetCurrent());
    

    
}
- (void)doOtherTask
{
    NSLog(@"do other task");
}
@end
