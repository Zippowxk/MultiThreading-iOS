//
//  CNThread.m
//  01 Thread
//
//  Created by wang xinkai on 15/9/13.
//  Copyright (c) 2015年 wxk. All rights reserved.
//

#import "CNThread.h"

@implementation CNThread

-(id)initWithTarget:(id)target selector:(SEL)selector object:(id)argument{

    if (self = [super initWithTarget:target selector:selector object:argument]){
    
        _target = target;
        _sel = selector;

    }
    
    return self;
    
}



-(void)main{

//    父类的main方法中，_target 会掉用_sel
    if (_target) {
        [_target performSelector:_sel withObject:nil];
    }

    

//    进入线程注入口
    
    
}

@end
