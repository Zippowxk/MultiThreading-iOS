//
//  ViewController.m
//  02 ThreadRoutine
//
//  Created by wang xinkai on 15/9/13.
//  Copyright (c) 2015年 wxk. All rights reserved.
//

#import "ViewController.h"
#import "CNThread.h"
@interface ViewController ()
{
    int _repeatCount;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    NSThread *thread_0 = [[NSThread alloc] initWithTarget:self selector:@selector(threadRoutine) object:nil];
    
    thread_0.name  = @"thread_0_name";
    
//    [thread_0 start];
    
    
    CNThread *thread = [[CNThread alloc] init];
    thread.name = @"cn_thread";
    [thread start];
    
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [thread cancel];
    });
    


}

//完善入口
//1. autorelease
//2. RunLoop



-(void)routine{

//    这样在线程中创建的autorelease对象就可以在线程结束的时候释放,避免过多的延迟释 放造成程序占用过多的内存
    @autoreleasepool {
    
        [[NSThread currentThread].threadDictionary setObject:@(false) forKey:@"isExit"];
        
        
        
       NSTimer *timer = [NSTimer timerWithTimeInterval:3 target:self selector:@selector(repeatAction) userInfo:nil repeats:YES];

        
//        除了timer的方法 执行其他方法
        [self performSelector:@selector(doTask) withObject:nil afterDelay:3];
        
//        添加时间源
        [[NSRunLoop currentRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];

        

        while (true) {
            
            
            [self doOtherTask];
            //        开始Loop方法 (超时时间)
            [[NSRunLoop currentRunLoop] runMode:NSRunLoopCommonModes beforeDate:[NSDate distantFuture]];
            
            
            
        }

      }
}


- (void)threadRoutine
{
    
    @autoreleasepool {
        
    
        BOOL moreWorkToDo = YES;
        BOOL exitNow = NO;
        NSRunLoop* runLoop = [NSRunLoop currentRunLoop];
        NSMutableDictionary* threadDict = [[NSThread currentThread]
                                           threadDictionary];
        [threadDict setValue:[NSNumber numberWithBool:exitNow]
                      forKey:@"ThreadShouldExitNow"];
//    核心代码
        //添加事件源
        NSTimer *timer = [NSTimer timerWithTimeInterval:5 target:self selector:@selector(repeatAction) userInfo:nil repeats:YES];
        //        添加时间源
        [[NSRunLoop currentRunLoop] addTimer:timer forMode:NSDefaultRunLoopMode];
        
//    核心代码
        //终止线程
        while (moreWorkToDo && !exitNow)
        {
            [self doOtherTask];
//          核心代码
//            执⾏行线程真正的⼯工作⽅方法,如果完成了可以设置moreWorkToDo为False
            BOOL res = [runLoop runMode:NSDefaultRunLoopMode beforeDate:[NSDate distantFuture]];
            exitNow = [[threadDict valueForKey:@"ThreadShouldExitNow"]
                       boolValue];
        }
    }
}



-(void)doOtherTask{
    
    
    NSLog(@"do other task");
}

-(void)doTask{

    NSLog(@"do task...");
    
}


-(void)repeatAction{
    
    _repeatCount++;
    NSLog(@"...repeat %d %@",_repeatCount,[NSThread currentThread]);
    
//    核心代码
    CFRunLoopStop(CFRunLoopGetCurrent());
    
    if (_repeatCount == 10) {
        [[NSThread currentThread].threadDictionary setObject:@(true) forKey:@"ThreadShouldExitNow"];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
