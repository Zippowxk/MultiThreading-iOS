//
//  CNThread.h
//  01 Thread
//
//  Created by wang xinkai on 15/9/13.
//  Copyright (c) 2015年 wxk. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CNThread : NSThread
{
    id _target;
    SEL _sel;
}
@end
